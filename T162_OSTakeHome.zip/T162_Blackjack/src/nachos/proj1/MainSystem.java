package nachos.proj1;

import java.util.Vector;

public class MainSystem {

	MainConsole mc = new MainConsole();
	MainFileSystem fs = new MainFileSystem();
	MainNetworkLink nl = new MainNetworkLink();
	public static Vector<User> userList = new Vector<>();

	public void menu() {
		mc.println("WU Blackjack!");
		mc.println("Welcome Dealer");
		mc.println("1. Start Game");
		mc.println("2. See high scores");
		mc.println("3. Exit");
		int inp = -1;
		do {
			mc.print("Choose >> ");
			inp = mc.getInt();
		} while (inp < 1 || inp > 3);
		switch (inp) {
		case 1:
			startGame();
			break;
		case 2:
			highScore();
		case 3:
			break;
		default:
			break;
		}
	}

	public void startGame() {
		mc.println("start");
	}

	public void highScore() {
		for (int i = 0; i < userList.size(); i++) {
			mc.println("Name : " + userList.get(i).getUname() + ", Score : " + userList.get(i).getScore());
		}
		mc.read();
		menu();
	}

	public void read() {
		String fileName = "highscore.txt";
		String str = fs.readFile(fileName);
		if (str == null) {
			mc.println("Highscore is empty!");
			fs.writeFile("\n", fileName);
			menu();
			return;
		}
		if (str.isEmpty()) {
			mc.println("Highschore is empty!");
			return;
		}
		String ar[] = str.split("\n");
		int len = ar.length;
		for (int i = 0; i < len; i++) {
			int lenAr = ar[i].length();
			String tempStr = ar[i];
			userList.add(new User(tempStr));
		}
	}
	
	public void dealerMenu() {
		System.out.println("Welcome Dealer");
	}
	
	public MainSystem() {
		read();
		if(nl.getAddress()==0) {
			dealerMenu();
			menu();
		}else {
			menu();
		}
	}

}
