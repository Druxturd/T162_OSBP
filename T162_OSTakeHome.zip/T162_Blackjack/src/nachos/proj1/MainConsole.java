package nachos.proj1;

import nachos.machine.Machine;
import nachos.machine.SerialConsole;
import nachos.threads.Semaphore;

public class MainConsole {

	SerialConsole sc = Machine.console();
	Semaphore sem = new Semaphore(0);
	char inp;
	
	public MainConsole() {
		Runnable recv = new Runnable() {
			
			@Override
			public void run() {
				inp = (char)sc.readByte();
				sem.V();
			}
		};
		
		Runnable send = new Runnable() {
			
			@Override
			public void run() {
				sem.V();
			}
		};
		sc.setInterruptHandlers(recv, send);
	}
	
	public void print(String str) {
		int len=str.length();
		for(int i=0; i<len; i++) {
			sc.writeByte(str.charAt(i));
			sem.P();
		}
	}
	
	public void println(String str) {
		print(str+"\n");
	}
	
	public String read() {
		String str="";
		for(;;) {
			sem.P();
			if(inp=='\n') {
				break;
			}
			str+=inp;
		}
		return str;
	}
	
	public int getInt() {
		int num = -1;
		String str = read();
		try {
			num = Integer.parseInt(str);
		} catch (Exception e) {
			println("Invalid Input!");
		}
		return num;
	}
	
	public char getInp() {
		return inp;
	}

}
