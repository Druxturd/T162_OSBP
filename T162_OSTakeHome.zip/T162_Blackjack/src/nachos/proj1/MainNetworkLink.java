package nachos.proj1;

import nachos.machine.Machine;
import nachos.machine.NetworkLink;
import nachos.machine.Packet;
import nachos.threads.Semaphore;

public class MainNetworkLink {

	private NetworkLink nl = Machine.networkLink();
	private Semaphore sem = new Semaphore(0);
	
	public int getAddress() {
		return nl.getLinkAddress();
	}
	
	public boolean sendPacket(int dest, User user) {
		String str = user.serialize();
		byte [] data = str.getBytes();
		try {
			Packet curr = new Packet(dest, getAddress(), data);
			nl.send(curr);
			sem.P();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public MainNetworkLink() {
		Runnable recv = new Runnable() {
			
			@Override
			public void run() {
				Packet curr = nl.receive();
				String str = new String(curr.contents);
				sem.V();
			}
		};
		
		Runnable send = new Runnable() {
			
			@Override
			public void run() {
				sem.V();
			}
		};
		nl.setInterruptHandlers(recv, send);
	}

}
