package nachos.proj1;

import nachos.machine.FileSystem;
import nachos.machine.Machine;
import nachos.machine.OpenFile;

public class MainFileSystem {

	private FileSystem fs = Machine.stubFileSystem();

	public MainFileSystem() {
		// TODO Auto-generated constructor stub
	}

	public String readFile(String file) {
		OpenFile of = fs.open(file, false);
		if (of == null) {
			return null;
		}
		byte[] buff = new byte[1024];
		if (of.read(buff, 0, 1024) == -1)
			return null;
		return new String(buff).trim();
	}

	public boolean checkFile(String file) {
		OpenFile of = fs.open(file, true);
		if (of == null) {
			return false;
		}
		return true;
	}

	public boolean writeFile(String str, String file) {
		OpenFile of = fs.open(file, true);
		int check = of.write(str.getBytes(), 0, str.getBytes().length);
		if (check == -1) {
			return false;
		} else {
			return true;
		}
	}

}
