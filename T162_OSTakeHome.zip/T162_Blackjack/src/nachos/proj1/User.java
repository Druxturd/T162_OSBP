package nachos.proj1;

public class User {

	private String uname;
	private int score;
	private Integer power;

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public Integer getPower() {
		return power;
	}

	public void setPower(Integer power) {
		this.power = power;
	}

	public User(String uname, int score, Integer power) {
		super();
		this.uname = uname;
		this.score = score;
		this.power = power;
	}

	public String serialize() {
		return uname + ";" + "score";
	}

	public User(String str) {
		String ar[] = str.split(";");
		uname = ar[0];
		score = Integer.parseInt(ar[1]);
	}

}
